﻿global using DataAccess.Data;
global using DataAccess.Models;